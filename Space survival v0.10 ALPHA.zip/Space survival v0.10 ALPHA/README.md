# 🚀 Space Survival

## 🎯 Cel gry
Celem gry jest **przetrwanie jak najdłużej** w kosmosie, unikając asteroid i zbierając power-upy.
Gracz steruje rakietą, która porusza się w lewo i prawo, a każda zebrana tarcza lub bonus punktowy zwiększa szansę na dłuższe przetrwanie.

-----------------------------

## ⚙️ Zasada działania
- **Rakieta** porusza się w lewo/prawo (strzałeczki na klawiaturze "<- oraz ->").
- **Asteroidy** spadają z góry z różną prędkością.
- **Power-upy** mogą dać dodatkowe punkty, ochronną tarczę lub spowolnić asteroidy.
- **Kolizja z asteroidą** kończy grę, chyba że gracz ma aktywną tarczę lub więcej żyć.
- Wynik punktowy rośnie wraz z unikaniem przeszkód.
